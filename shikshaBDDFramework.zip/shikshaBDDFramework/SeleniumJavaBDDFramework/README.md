# Selenium Java BDD Framework

Java 17 Selenium WebDriver 4 automation using Cucumber JVM, TestNG, PageFactory, Apache POI, Extent Reports, and Log4j 2.

## Project layout

- `src/test/java/com/pages` - PageFactory page objects and business actions.
- `src/test/java/com/stepDefinition` - thin Cucumber glue with TestNG assertions.
- `src/test/java/com/setup` - browser factory, thread-scoped driver, runner hooks, and shared step base.
- `src/test/java/com/parameters` - configuration and TestNG/Excel data provider.
- `src/test/java/com/utilities` - explicit waits, element actions, JavaScript, screenshots, and Excel reading.
- `src/test/java/com/context` - per-scenario state.
- `src/test/java/com/reporting` - thread-safe Extent HTML and JSON reporting.
- `src/test/resources/Features` - business-readable Shiksha MBA scenarios.
- `src/test/resources/PropertyFiles/config.properties` - local, non-secret defaults.

## Configuration

Set `baseUrl` before running browser scenarios. Configuration precedence is Java system property, `BDD_`-prefixed environment variable, then `config.properties`. For example, in PowerShell:

```powershell
$env:BDD_BASEURL = "<application-base-url>"
$env:BDD_BROWSER = "chrome"
$env:BDD_HEADLESS = "true"
mvn clean test
```

Alternatively, pass `-DbaseUrl=<application-base-url>`. Supported browsers are `chrome`, `firefox`, and `edge`; Selenium Manager resolves browser drivers. No browser driver executable path is required.

Supported settings:

| Key | Default | Description |
| --- | --- | --- |
| `baseUrl` | empty | Application entry point; required to run scenarios. |
| `browser` | `chrome` | `chrome`, `firefox`, or `edge`. |
| `headless` | `false` | Run the selected browser without a visible window. |
| `explicitWaitTimeout` | `10` | Explicit wait timeout in seconds. |
| `pageLoadTimeout` | `30` | Page-load timeout in seconds. |
| `scriptTimeout` | `20` | JavaScript timeout in seconds. |
| `reportPath` | `test-output/reports` | Extent HTML and JSON output directory. |
| `screenshotPath` | `test-output/screenshots` | Failure screenshot directory. |
| `testDataPath` | `src/test/resources/ExcelFiles/TestData.xlsx` | Workbook used by the TestNG Excel data provider. |

To use a separate properties file, set `-Dconfig.file=<path>`. Individual values can still be overridden using system properties or environment variables such as `BDD_EXPLICITWAITTIMEOUT`.

## Running tests

The TestNG Cucumber runner defaults to `@smoke`. Override tags as needed:

```powershell
mvn clean test "-Dcucumber.filter.tags=@regression"
mvn clean test "-Dcucumber.filter.tags=@TC-019"
```

Set `BDD_BASEURL` or `-DbaseUrl` for every browser run. Feature selectors are intentionally contained in Page Objects; confirm selectors against the target environment when its UI changes.

## Reports and artifacts

- Extent report: `test-output/reports/extent-report.html`
- Extent JSON: `test-output/reports/extent-report.json`
- Failure screenshots: `test-output/screenshots`
- Surefire/TestNG output: `target/surefire-reports`
- Log: `test-output/logs/automation.log`

Hooks record passed, failed, and skipped Cucumber scenarios. Failed scenarios attach a screenshot to both the Cucumber scenario and the Extent report. Browser teardown and scenario context cleanup run from the `@After` hook.

## Supplied MBA case coverage

| Case | Feature coverage |
| --- | --- |
| TC-001 | Filter ranked college listings by location and fee threshold, then shortlist a result. |
| TC-008 | Open a popular MBA comparison and verify its heading. |
| TC-017 | Open the CAT Complete Syllabus as a new tab or PDF. |
| TC-018 | Submit a ShikshaGPT question and continue a valid MBA student question. |
| TC-019 | Verify the mandatory-question validation and prevent progression. |

Scenarios use browser-facing Page Object actions and require a target URL and compatible site selectors; the framework does not assume credentials or embed an application URL.
