package com.setup;

import com.context.ScenarioContext;

public abstract class BaseSteps {
    protected final ScenarioContext context;

    protected BaseSteps(ScenarioContext context) {
        this.context = context;
    }
}