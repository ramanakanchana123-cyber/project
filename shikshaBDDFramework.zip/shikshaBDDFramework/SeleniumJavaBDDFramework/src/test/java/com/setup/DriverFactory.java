package com.setup;

import com.parameters.ConfigReader;
import org.openqa.selenium.WebDriver;

public final class DriverFactory {
    private DriverFactory() {
    }

    public static WebDriver createDriver(ConfigReader config) {
        return BrowserFactory.create(config);
    }
}