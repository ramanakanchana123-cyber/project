package com.setup;

import com.aventstack.extentreports.ExtentTest;
import com.context.ScenarioContext;
import com.parameters.ConfigReader;
import com.pages.ExamPage;
import com.pages.HomePage;
import com.pages.MbaLandingPage;
import com.pages.QuestionPage;
import com.pages.SaveCoursePage;
import com.pages.SearchPage;
import com.reporting.ExtentReportManager;
import com.utilities.ScreenshotUtils;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.Status;
import java.io.IOException;
import java.nio.file.Path;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

public final class Hooks {
    private static final Logger LOGGER = LogManager.getLogger(Hooks.class);
    private final ScenarioContext context;

    public Hooks(ScenarioContext context) {
        this.context = context;
    }

    @Before
    public void setUp(Scenario scenario) {
        ConfigReader config = new ConfigReader();
        ExtentTest extentTest = ExtentReportManager.createTest(scenario.getName());
        ExtentReportManager.setTest(extentTest);
        context.set("config", config);
        try {
            config.require("baseUrl");
            WebDriver driver = BrowserFactory.create(config);
            DriverManager.setDriver(driver);
            driver.manage().timeouts()
                    .pageLoadTimeout(config.getDuration("pageLoadTimeout"))
                    .scriptTimeout(config.getDuration("scriptTimeout"));
            initializePages(driver, config);
            LOGGER.info("Started scenario '{}' using browser '{}'", scenario.getName(), config.get("browser"));
        } catch (RuntimeException exception) {
            extentTest = ExtentReportManager.getTest();
            if (extentTest != null) {
                extentTest.fail("Scenario setup failed: " + exception.getMessage());
            }
            throw exception;
        }
    }

    private void initializePages(WebDriver driver, ConfigReader config) {
        context.set("homePage", new HomePage(driver, config));
        context.set("mbaLandingPage", new MbaLandingPage(driver, config));
        context.set("searchPage", new SearchPage(driver, config));
        context.set("saveCoursePage", new SaveCoursePage(driver, config));
        context.set("examPage", new ExamPage(driver, config));
        context.set("questionPage", new QuestionPage(driver, config));
    }

    @After
    public void tearDown(Scenario scenario) {
        ExtentTest extentTest = ExtentReportManager.getTest();
        try {
            if (scenario.isFailed() && DriverManager.hasDriver()) {
                Path screenshot = ScreenshotUtils.capture(
                        DriverManager.getDriver(),
                        context.config().getPath("screenshotPath"),
                        scenario.getName());
                byte[] screenshotBytes = java.nio.file.Files.readAllBytes(screenshot);
                scenario.attach(screenshotBytes, "image/png", screenshot.getFileName().toString());
                if (extentTest != null) {
                    extentTest.addScreenCaptureFromPath(screenshot.toString());
                }
            }
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("Unable to capture or attach failure screenshot for scenario '{}'",
                    scenario.getName(), exception);
            if (extentTest != null) {
                extentTest.warning("Failure screenshot could not be attached: " + exception.getMessage());
            }
        } finally {
            try {
                if (extentTest != null) {
                    updateReportStatus(scenario, extentTest);
                }
            } finally {
                try {
                    DriverManager.quitDriver();
                } finally {
                    try {
                        context.clear();
                        LOGGER.info("Finished scenario '{}' with status '{}'",
                                scenario.getName(), scenario.getStatus());
                    } finally {
                        ExtentReportManager.clearTest();
                    }
                }
            }
        }
    }

    @AfterAll
    public static void flushExtentReport() {
        ExtentReportManager.flushReports();
    }

    private void updateReportStatus(Scenario scenario, ExtentTest extentTest) {
        Status status = scenario.getStatus();
        if (status == Status.PASSED) {
            extentTest.pass("Scenario passed");
        } else if (status == Status.FAILED) {
            extentTest.fail("Scenario failed");
        } else {
            extentTest.skip("Scenario status: " + status);
        }
    }
}