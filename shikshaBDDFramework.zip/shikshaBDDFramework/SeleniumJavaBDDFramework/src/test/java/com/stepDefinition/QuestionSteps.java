package com.stepDefinition;

import com.context.ScenarioContext;
import com.setup.BaseSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

public class QuestionSteps extends BaseSteps {
    public QuestionSteps(ScenarioContext context) {
        super(context);
    }

    @When("the applicant opens Ask a Question from MBA resources")
    public void applicantOpensAskQuestionFromResources() {
        context.mbaLandingPage().openMbaModule();
        context.mbaLandingPage().openResourceQuestionPage();
        context.questionPage().openAskQuestionSubmissionForm();
    }

    @When("the applicant submits the question {string} without selecting a course")
    public void applicantSubmitsQuestionWithoutSelectingCourse(String question) throws InterruptedException {
        context.questionPage().submitQuestionWithoutCourse(question);
    }

    @When("the applicant submits the chatbot question {string}")
    public void applicantSubmitsChatbotQuestion(String question) {
        context.questionPage().submitChatbotQuestion(question);
    }

    @Then("the chatbot should display a response")
    public void chatbotShouldDisplayResponse() {
        Assert.assertTrue(context.questionPage().hasChatbotResponse(),
                "The chatbot should display a response or acknowledgement");
    }

    @When("the applicant opens the MBA student questions page")
    public void applicantOpensMbaStudentQuestionsPage() {
        context.mbaLandingPage().openMbaModule();
        context.mbaLandingPage().openAskCurrentStudents();
        context.mbaLandingPage().openPopularCollegeQuestions();
    }

    @And("the applicant opens the question form")
    public void applicantOpensQuestionForm() {
        context.questionPage().openAskQuestionForm();
    }

    @When("the applicant opens the first unanswered question to answer")
    public void applicantOpensFirstUnansweredQuestionToAnswer() {
        context.questionPage().openFirstUnansweredAnswerForm();
    }

    @Then("the college sections should match these checks:")
    public void collegeSectionsShouldMatchChecks(DataTable checksTable) {
        List<Map<String, String>> checks = checksTable.asMaps(String.class, String.class);
        if (checks.isEmpty()) {
            throw new IllegalArgumentException("Provide at least one college section check");
        }

        for (Map<String, String> check : checks) {
            String section = check.get("section");
            String expectedCheck = check.get("check");
            if (section == null || section.isBlank() || expectedCheck == null) {
                throw new IllegalArgumentException(
                        "Each college section check requires section and check values");
            }

            context.questionPage().openCollegeSection(section);
            switch (expectedCheck) {
                case "details-visible" -> Assert.assertTrue(
                        context.questionPage().isCollegeCutoffDisplayed(),
                        "The " + section + " section should display cutoff details");
                case "rank-above" -> {
                    String thresholdValue = check.get("threshold");
                    if (thresholdValue == null || thresholdValue.isBlank()) {
                        throw new IllegalArgumentException(
                                "A threshold is required for the rank-above check");
                    }
                    int threshold;
                    try {
                        threshold = Integer.parseInt(thresholdValue);
                    } catch (NumberFormatException exception) {
                        throw new IllegalArgumentException(
                                "Ranking threshold must be an integer: " + thresholdValue, exception);
                    }
                    Assert.assertTrue(context.questionPage().hasCollegeRankAbove(threshold),
                            "At least one displayed college rank should be greater than " + threshold);
                }
                default -> throw new IllegalArgumentException(
                        "Unsupported college section check: " + expectedCheck);
            }
        }
    }

    @And("the applicant enters the answer {string}")
    public void applicantEntersAnswer(String answer) {
        context.questionPage().enterAnswer(answer);
    }

    @And("the applicant selects the course {string}")
    public void applicantSelectsCourse(String course) {
        context.questionPage().chooseCourse(course);
    }

    @And("the applicant enters the question {string}")
    public void applicantEntersQuestion(String question) {
        context.questionPage().enterQuestion(question);
    }

    @And("the applicant enters the description {string}")
    public void applicantEntersDescription(String description) {
        context.questionPage().enterDescription(description);
    }

    @When("the applicant continues without entering a question")
    public void applicantContinuesWithoutQuestion() {
        context.questionPage().continueQuestionSubmission();
    }

    @When("the applicant continues to the next question step")
    public void applicantContinuesToNextQuestionStep() {
        context.questionPage().continueQuestionSubmission();
    }

    @Then("the next question step should show the Post action")
    public void nextQuestionStepShouldShowPostAction() {
        Assert.assertTrue(context.questionPage().postPageIsDisplayed(),
                "The next step should display the Post action");
    }

    @When("the applicant clicks Post")
    public void applicantClicksPost() {
        context.questionPage().postQuestion();
    }

    @Then("a sign-in prompt should be displayed to post the question")
    public void signInPromptShouldBeDisplayedToPostQuestion() {
        Assert.assertTrue(context.questionPage().isLoginPromptDisplayed(),
                "Posting while signed out should request registration or sign-in");
    }

    @Then("a sign-in prompt should be displayed to post the answer")
    public void signInPromptShouldBeDisplayedToPostAnswer() {
        Assert.assertTrue(context.questionPage().isLoginPromptDisplayed(),
                "Posting an answer while signed out should request registration or sign-in");
    }

    @Then("a mandatory question validation message should be displayed")
    public void mandatoryQuestionValidationShouldBeDisplayed() {
        Assert.assertTrue(context.questionPage().isQuestionRequiredMessageDisplayed(),
                "A validation message should explain that the question is mandatory");
    }

    @Then("the applicant should remain on the question form")
    public void applicantShouldRemainOnQuestionForm() {
        Assert.assertFalse(context.questionPage().postPageIsDisplayed(),
                "The Post step must not be displayed when the question is blank");
    }
}
