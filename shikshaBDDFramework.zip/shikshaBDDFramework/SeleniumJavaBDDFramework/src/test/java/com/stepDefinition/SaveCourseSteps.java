package com.stepDefinition;

import com.context.ScenarioContext;
import com.setup.BaseSteps;
import com.utilities.TestDataUtils;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

public class SaveCourseSteps extends BaseSteps {
    public SaveCourseSteps(ScenarioContext context) {
        super(context);
    }

    @When("the applicant shortlists the first college")
    public void applicantShortlistsFirstCollege() {
        context.saveCoursePage().shortlistFirstCollege();
    }

    @When("the applicant searches for the college from Excel within the ranking")
    public void applicantSearchesForCollegeFromExcel() {
        List<Map<String, String>> records;
        try {
            records = TestDataUtils.readSheet(context.config().getPath("testDataPath"), "TestData");
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read college search test data from Excel", exception);
        }
        if (records.isEmpty()) {
            throw new IllegalStateException("The TestData sheet has no college search data");
        }
        String collegeName = records.get(0).get("collegeName");
        if (collegeName == null || collegeName.isBlank()) {
            throw new IllegalStateException("The first TestData row must include a collegeName value");
        }
        context.set("searchedCollegeName", collegeName);
        context.searchPage().searchCollegeWithinRanking(collegeName);
    }

    @Then("the college from Excel should appear in the ranking results")
    public void collegeFromExcelShouldAppearInSearchResults() {
        String collegeName = context.get("searchedCollegeName", String.class);
        Assert.assertTrue(context.searchPage().hasCollegeNamedInRanking(collegeName),
                "Ranking results should display the college from Excel: " + collegeName);
    }

    @Then("the college should be added to the applicant's shortlist")
    public void collegeShouldBeShortlisted() {
        Assert.assertTrue(context.saveCoursePage().isCollegeShortlisted(),
                "The first college should show a saved or shortlisted state");
    }
}