package com.stepDefinition;

import com.context.ScenarioContext;
import com.setup.BaseSteps;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class FilterSteps extends BaseSteps {
    public FilterSteps(ScenarioContext context) {
        super(context);
    }

    @When("the applicant opens top ranked MBA colleges")
    public void applicantOpensTopRankedMbaColleges() {
        context.mbaLandingPage().openTopRankedColleges();
    }

    @When("the applicant filters colleges by location {string}")
    public void applicantFiltersColleges(String location) {
        context.mbaLandingPage().filterCollegesBy(location);
    }

    @Then("the location filter {string} should be selected")
    public void locationFilterShouldBeSelected(String location) {
        Assert.assertTrue(context.mbaLandingPage().isLocationFilterSelected(location),
                "The location filter should remain selected after applying it: " + location);
    }
}