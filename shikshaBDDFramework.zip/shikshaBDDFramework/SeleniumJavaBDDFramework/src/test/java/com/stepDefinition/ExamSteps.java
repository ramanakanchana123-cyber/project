package com.stepDefinition;

import com.context.ScenarioContext;
import com.setup.BaseSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

public class ExamSteps extends BaseSteps {
    public ExamSteps(ScenarioContext context) {
        super(context);
    }

    @When("the applicant opens an exam syllabus PDF from MBA exams:")
    public void applicantOpensExamSyllabusPdf(DataTable examTable) {
        List<Map<String, String>> examRows = examTable.asMaps(String.class, String.class);
        if (examRows.size() != 1) {
            throw new IllegalArgumentException("Provide exactly one exam in the exam data table");
        }
        String examName = examRows.get(0).get("exam");
        if (examName == null || examName.isBlank()) {
            throw new IllegalArgumentException("The exam data table must include a non-empty exam value");
        }
        context.mbaLandingPage().openMbaModule();
        context.mbaLandingPage().openExams();
        context.examPage().openExam(examName);
        context.examPage().openSyllabusPdf();
    }

    @Then("the exam PDF should open successfully")
    public void examPdfShouldOpenSuccessfully() {
        Assert.assertTrue(context.examPage().pdfOpenedSuccessfully(),
                "The exam Download PDF link should open a PDF in the browser");
    }
}
