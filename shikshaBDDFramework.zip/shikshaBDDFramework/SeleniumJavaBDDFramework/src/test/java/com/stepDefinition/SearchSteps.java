package com.stepDefinition;

import com.context.ScenarioContext;
import com.setup.BaseSteps;
import com.utilities.TestDataUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

public class SearchSteps extends BaseSteps {
    public SearchSteps(ScenarioContext context) {
        super(context);
    }

    @Given("the applicant is on the Shiksha home page")
    public void applicantIsOnHomePage() {
        context.homePage().open();
        Assert.assertTrue(context.homePage().isLoaded(), "Shiksha home page should be displayed");
    }

    @When("the applicant selects the MBA module")
    public void applicantSelectsMbaModule() {
        context.mbaLandingPage().openMbaModule();
    }

    @When("the applicant opens the popular MBA comparison from Excel")
    public void applicantOpensPopularMbaComparisonFromExcel() {
        List<Map<String, String>> records;
        try {
            records = TestDataUtils.readSheet(context.config().getPath("testDataPath"), "TestData");
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read comparison test data from Excel", exception);
        }
        if (records.isEmpty()) {
            throw new IllegalStateException("The TestData sheet has no comparison data");
        }
        String comparisonName = records.get(0).get("popularComparison");
        if (comparisonName == null || comparisonName.isBlank()) {
            throw new IllegalStateException("The first TestData row must include a popularComparison value");
        }
        context.set("popularComparison", comparisonName);
        context.mbaLandingPage().openPopularComparison(comparisonName);
    }

    @Then("the comparison URL should contain the comparison from Excel")
    public void comparisonUrlShouldContainComparisonFromExcel() {
        String comparisonName = context.get("popularComparison", String.class);
        Assert.assertTrue(context.searchPage().urlContainsComparison(comparisonName),
                "The URL should contain the selected comparison: " + comparisonName);
    }

    @Then("the comparison heading should be displayed")
    public void comparisonHeadingShouldBeDisplayed() {
        Assert.assertTrue(context.searchPage().hasComparisonHeading(),
                "A comparison heading should be visible on the MBA comparison page");
    }

    @When("the applicant searches for {string}")
    public void applicantSearchesFor(String query) {
        context.homePage().searchFor(query);
    }

    @Then("matching college results should be displayed")
    public void matchingCollegeResultsShouldBeDisplayed() {
        Assert.assertTrue(context.searchPage().hasCollegeResults(),
                "At least one matching college should be displayed");
    }
}