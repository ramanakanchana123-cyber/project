package com.context;

import com.pages.ExamPage;
import com.pages.HomePage;
import com.pages.MbaLandingPage;
import com.pages.QuestionPage;
import com.pages.SaveCoursePage;
import com.pages.SearchPage;
import com.parameters.ConfigReader;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ScenarioContext {
    private final Map<String, Object> values = new ConcurrentHashMap<>();

    public void set(String key, Object value) {
        values.put(key, value);
    }

    public <T> T get(String key, Class<T> type) {
        Object value = values.get(key);
        if (!type.isInstance(value)) {
            throw new IllegalStateException("Scenario context value '" + key + "' is not available");
        }
        return type.cast(value);
    }

    public ConfigReader config() {
        return get("config", ConfigReader.class);
    }

    public HomePage homePage() {
        return get("homePage", HomePage.class);
    }

    public MbaLandingPage mbaLandingPage() {
        return get("mbaLandingPage", MbaLandingPage.class);
    }

    public SearchPage searchPage() {
        return get("searchPage", SearchPage.class);
    }

    public SaveCoursePage saveCoursePage() {
        return get("saveCoursePage", SaveCoursePage.class);
    }

    public ExamPage examPage() {
        return get("examPage", ExamPage.class);
    }

    public QuestionPage questionPage() {
        return get("questionPage", QuestionPage.class);
    }

    public void clear() {
        values.clear();
    }
}
