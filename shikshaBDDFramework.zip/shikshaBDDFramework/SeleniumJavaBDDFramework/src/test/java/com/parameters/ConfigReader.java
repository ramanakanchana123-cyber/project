package com.parameters;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Locale;
import java.util.Properties;

public final class ConfigReader {
    private static final String DEFAULT_RESOURCE = "PropertyFiles/config.properties";
    private static final String ENV_PREFIX = "BDD_";

    private final Properties properties = new Properties();

    public ConfigReader() {
        load();
    }

    private void load() {
        String externalConfig = System.getProperty("config.file");
        try (InputStream input = externalConfig == null || externalConfig.isBlank()
                ? Thread.currentThread().getContextClassLoader().getResourceAsStream(DEFAULT_RESOURCE)
                : Files.newInputStream(Path.of(externalConfig))) {
            if (input == null) {
                throw new IllegalStateException("Configuration resource not found: " + DEFAULT_RESOURCE);
            }
            properties.load(input);
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to load automation configuration", exception);
        }
    }

    public String get(String key) {
        String systemOverride = System.getProperty(key);
        if (systemOverride != null) {
            return systemOverride.trim();
        }
        String environmentOverride = System.getenv(ENV_PREFIX + key.toUpperCase(Locale.ROOT));
        if (environmentOverride != null) {
            return environmentOverride.trim();
        }
        return properties.getProperty(key, "").trim();
    }

    public String require(String key) {
        String value = get(key);
        if (value.isBlank()) {
            throw new IllegalStateException("Required configuration value is missing: " + key
                    + ". Set it in config.properties, as a system property, or as an environment override.");
        }
        return value;
    }

    public boolean getBoolean(String key) {
        String value = get(key);
        if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
            throw new IllegalArgumentException("Configuration value '" + key + "' must be true or false");
        }
        return Boolean.parseBoolean(value);
    }

    public int getInt(String key) {
        try {
            return Integer.parseInt(get(key));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Configuration value '" + key + "' must be an integer", exception);
        }
    }

    public Duration getDuration(String key) {
        int seconds = getInt(key);
        if (seconds <= 0) {
            throw new IllegalArgumentException("Configuration value '" + key + "' must be greater than zero");
        }
        return Duration.ofSeconds(seconds);
    }

    public Path getPath(String key) {
        return Path.of(require(key)).toAbsolutePath().normalize();
    }
}
