package com.parameters;

public final class PropertyReader {
    private final ConfigReader config;

    public PropertyReader() {
        this.config = new ConfigReader();
    }

    public String getProperty(String key) {
        return config.get(key);
    }

    public String getRequiredProperty(String key) {
        return config.require(key);
    }
}