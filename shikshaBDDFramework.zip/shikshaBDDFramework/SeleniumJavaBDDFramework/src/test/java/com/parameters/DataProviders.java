package com.parameters;

import com.utilities.TestDataUtils;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.testng.annotations.DataProvider;

public final class DataProviders {
    private DataProviders() {
    }

    @DataProvider(name = "excelTestData")
    public static Object[][] excelTestData() {
        ConfigReader config = new ConfigReader();
        try {
            List<Map<String, String>> records = TestDataUtils.readSheet(
                    config.getPath("testDataPath"), "TestData");
            return records.stream()
                    .map(record -> new Object[]{record})
                    .toArray(Object[][]::new);
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read Excel test data", exception);
        }
    }
}