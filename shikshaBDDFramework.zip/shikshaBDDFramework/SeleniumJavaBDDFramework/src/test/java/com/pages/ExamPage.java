package com.pages;

import com.parameters.ConfigReader;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExamPage extends BasePage {
    @FindBy(xpath = "//a[contains(normalize-space(.), 'Download PDF')]")
    private List<WebElement> downloadPdfLinks;

    public ExamPage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public void openExam(String examName) {
        String normalizedExamName = examName.trim();
        String examSlug = normalizedExamName.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-");
        String currentUrl = driver.getCurrentUrl().toLowerCase(Locale.ROOT);
        if (currentUrl.contains("/" + examSlug + "-exam")) {
            return;
        }

        By examLink = By.xpath("(//a|//button)[normalize-space()="
                + xpathLiteral(normalizedExamName)
                + " or normalize-space()=" + xpathLiteral(normalizedExamName + " Exam")
                + " or normalize-space()=" + xpathLiteral(normalizedExamName + " Exams")
                + " or contains(translate(@href,"
                + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '/"
                + examSlug + "-exam')]");
        click(waits.untilClickable(waits.untilPresent(examLink)));
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(webDriver -> webDriver.getCurrentUrl().toLowerCase(Locale.ROOT)
                        .contains("/" + examSlug + "-exam"));
    }

    public void openSyllabusPdf() {
        WebElement downloadLink = firstVisibleDownloadLink();
        scrollTo(downloadLink);
        Set<String> existingWindows = driver.getWindowHandles();
        String currentWindow = driver.getWindowHandle();
        click(downloadLink);

        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(webDriver -> webDriver.getWindowHandles().size() > existingWindows.size()
                        || isPdfUrl(webDriver.getCurrentUrl()));
        for (String windowHandle : driver.getWindowHandles()) {
            if (!existingWindows.contains(windowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }
        if (!driver.getWindowHandle().equals(currentWindow)) {
            new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                    .until(webDriver -> isPdfUrl(webDriver.getCurrentUrl()));
        }
    }

    public boolean pdfOpenedSuccessfully() {
        return isPdfUrl(driver.getCurrentUrl());
    }

    private WebElement firstVisibleDownloadLink() {
        return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(webDriver -> downloadPdfLinks.stream()
                        .filter(WebElement::isDisplayed)
                        .filter(WebElement::isEnabled)
                        .findFirst()
                        .orElse(null));
    }

    private boolean isPdfUrl(String url) {
        return url.toLowerCase(Locale.ROOT).matches(".*\\.pdf(?:[?#].*)?$");
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "',\"'\",'") + "')";
    }
}
