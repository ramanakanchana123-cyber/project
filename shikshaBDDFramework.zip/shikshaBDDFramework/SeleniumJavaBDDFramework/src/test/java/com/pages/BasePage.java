package com.pages;

import com.parameters.ConfigReader;
import com.utilities.ElementUtils;
import com.utilities.JavaScriptUtils;
import com.utilities.WaitUtils;
import java.util.Objects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public abstract class BasePage {
    @FindBy(tagName = "body")
    private WebElement pageBody;

    protected final WebDriver driver;
    protected final ConfigReader config;
    protected final WaitUtils waits;
    protected final ElementUtils elements;
    protected final JavaScriptUtils javascript;

    protected BasePage(WebDriver driver, ConfigReader config) {
        this.driver = Objects.requireNonNull(driver, "driver");
        this.config = Objects.requireNonNull(config, "config");
        this.waits = new WaitUtils(driver, config.getDuration("explicitWaitTimeout"));
        this.elements = new ElementUtils(waits);
        this.javascript = new JavaScriptUtils(driver);
        PageFactory.initElements(driver, this);
    }

    public void openApplication() {
        driver.get(config.require("baseUrl"));
    }

    protected void click(WebElement element) {
        try {
            elements.click(element);
        } catch (RuntimeException exception) {
            javascript.click(element);
        }
    }

    protected void type(WebElement element, String value) {
        elements.type(element, value);
    }

    protected void typeAndSubmit(WebElement element, String value) {
        elements.typeAndSubmit(element, value);
    }

    protected String text(WebElement element) {
        return elements.text(element);
    }

    protected boolean isDisplayed(WebElement element) {
        return elements.isDisplayed(element);
    }

    protected boolean isPresent(By locator) {
        try {
            waits.untilPresent(locator);
            return true;
        } catch (org.openqa.selenium.TimeoutException exception) {
            return false;
        }
    }

    protected void scrollTo(WebElement element) {
        javascript.scrollIntoView(element);
    }

    protected void clickWithJavaScript(WebElement element) {
        javascript.click(element);
    }

    protected void waitForPageLoad() {
        waits.untilVisible(pageBody);
        waits.untilPageLoaded();
    }
}