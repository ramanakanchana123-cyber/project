package com.pages;

import com.parameters.ConfigReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {
    @FindBy(css = "input[placeholder*='Search'], input[aria-label*='Search']")
    private WebElement siteSearch;

    @FindBy(css = "main h1, main h2")
    private WebElement homeHeading;

    public HomePage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public void open() {
        openApplication();
        waitForPageLoad();
    }

    public boolean isLoaded() {
        return isDisplayed(homeHeading) || isDisplayed(siteSearch);
    }

    public void searchFor(String query) {
        typeAndSubmit(siteSearch, query);
    }
}