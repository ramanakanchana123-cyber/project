package com.pages;

import com.parameters.ConfigReader;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MbaLandingPage extends BasePage {
    private static final String MODAL_OR_OVERLAY_SELECTOR = "*[contains(@class,'modal') or contains(@class,'overlay') or contains(@class,'popup') or contains(@class,'dialog')]";
    @FindBy(xpath = "//a[contains(@href, '/college/') and contains(@href, '/questions') "
            + "and (normalize-space()='XIME Bangalore' or normalize-space()='SIBM Pune' "
            + "or normalize-space()='JBIMS Mumbai' or normalize-space()='FMS' "
            + "or normalize-space()='IIM Ahmedabad' or normalize-space()='NMIMS')]")
    private List<WebElement> popularCollegeQuestionsLinks;

    @FindBy(css = "button[aria-label*='close'], [data-testid*='close'], [class*='close'], [class*='modal-close'], [data-qa*='close']")
    private List<WebElement> overlayCloseButtons;
    @FindBy(xpath = "(//a|//button)[normalize-space()='MBA' or normalize-space()='MBA Courses']")
    private WebElement mbaNavigationLink;

    @FindBy(xpath = "//a[@href='/mba/ranking/top-mba-colleges-in-india/2-2-0-0-0' and normalize-space()='Top MBA Colleges in India']")
    private WebElement topRankedCollegesLink;

    @FindBy(xpath = "(//a|//button)[normalize-space()='Compare Colleges']")
    private WebElement comparisonLink;

    @FindBy(xpath = "(//a|//button)[normalize-space()='Exams' or normalize-space()='MBA Exams' or contains(normalize-space(.),'MBA Exams')]")
    private WebElement examsLink;

    @FindBy(xpath = "(//a|//button)[normalize-space()='Ask Current MBA Students']")
    private WebElement askCurrentStudentsLink;

    @FindBy(xpath = "(//a|//button)[normalize-space()='Resources']")
    private WebElement resourcesLink;

    @FindBy(xpath = "(//a|//button)[normalize-space()='Ask a Question']")
    private WebElement resourceQuestionLink;

    public MbaLandingPage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public void openMbaModule() {
        dismissOverlayIfPresent();
        click(waits.untilClickable(mbaNavigationLink));
    }

    public void openTopRankedColleges() {
        click(topRankedCollegesLink);
        waits.untilUrlContains("/mba/ranking/top-mba-colleges-in-india/");
    }

    public void openPopularComparison(String comparisonName) {
        click(comparisonLink);
        By comparisonLink = By.xpath("//a[@el='MBA' and @ea='Compare Colleges' and normalize-space()="
                + xpathLiteral(comparisonName.trim()) + "]");
        click(firstVisibleElement(comparisonLink));
        String comparisonSlug = comparisonName.trim().toLowerCase(java.util.Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-");
        waits.untilUrlContains(comparisonSlug);
    }

    public void openExams() {
        dismissOverlayIfPresent();
        click(examsLink);
    }

    public void openAskCurrentStudents() {
        click(askCurrentStudentsLink);
    }

    public void openPopularCollegeQuestions() {
        click(firstVisibleElement(popularCollegeQuestionsLinks));
        waits.untilUrlContains("/college/");
        waits.untilUrlContains("/questions");
    }

    public void openResourceQuestionPage() {
        click(resourcesLink);
        click(resourceQuestionLink);
    }

    public void filterCollegesBy(String location) {
        String startingUrl = driver.getCurrentUrl();
        String normalizedLocation = location.trim().toLowerCase(java.util.Locale.ROOT);
        By locationLabel = By.xpath("//label[contains(translate(normalize-space(.),"
                + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), "
                + xpathLiteral(normalizedLocation) + ")]");
        WebElement label = firstVisibleElement(locationLabel);
        String checkboxId = label.getAttribute("for");
        if (checkboxId == null || checkboxId.isBlank()) {
            throw new IllegalStateException("Location filter has no associated checkbox: " + location);
        }
        WebElement checkbox = waits.untilPresent(By.id(checkboxId));
        scrollTo(label);
        clickWithJavaScript(checkbox);
        new org.openqa.selenium.support.ui.WebDriverWait(
                driver, config.getDuration("explicitWaitTimeout"))
                .until(webDriver -> !webDriver.getCurrentUrl().equals(startingUrl));
    }

    public boolean isLocationFilterSelected(String location) {
        String normalizedLocation = location.trim().toLowerCase(java.util.Locale.ROOT);
        By locationLabel = By.xpath("//label[contains(translate(normalize-space(.),"
                + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), "
                + xpathLiteral(normalizedLocation) + ")]");
        WebElement label = firstVisibleElement(locationLabel);
        String checkboxId = label.getAttribute("for");
        if (checkboxId == null || checkboxId.isBlank()) {
            throw new IllegalStateException("Location filter has no associated checkbox: " + location);
        }
        return waits.untilPresent(By.id(checkboxId)).isSelected();
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "',\"'\",'") + "')";
    }

    private void dismissOverlayIfPresent() {
        for (WebElement closeButton : overlayCloseButtons) {
            try {
                if (closeButton.isDisplayed()) {
                    click(closeButton);
                    return;
                }
            } catch (RuntimeException ignored) {
                // Ignore opaque overlay close buttons that are not interactable at the moment.
            }
        }
    }

    private WebElement firstVisibleElement(List<WebElement> candidates) {
        return new org.openqa.selenium.support.ui.WebDriverWait(
                driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> candidates.stream()
                        .filter(WebElement::isDisplayed)
                        .filter(WebElement::isEnabled)
                        .findFirst()
                        .orElse(null));
    }

    private WebElement firstVisibleElement(By locator) {
        return new org.openqa.selenium.support.ui.WebDriverWait(
                driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> currentDriver.findElements(locator).stream()
                        .filter(WebElement::isDisplayed)
                        .filter(WebElement::isEnabled)
                        .findFirst()
                        .orElse(null));
    }
}
