package com.pages;

import com.parameters.ConfigReader;
import java.util.Locale;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
public class SearchPage extends BasePage {
    @FindBy(css = "main h1, main h2, [data-testid='page-title']")
    private WebElement pageHeading;

    @FindBy(css = "main [data-testid='college-card'], main article, main [class*='college-card']")
    private WebElement firstCollegeCard;

    @FindBy(css = "input[placeholder*='college within this ranking']")
    private WebElement rankingCollegeSearch;

    public SearchPage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public String heading() {
        return text(pageHeading);
    }

    public boolean hasComparisonHeading() {
        return isDisplayed(pageHeading) && heading().toLowerCase(Locale.ROOT).contains("compar");
    }

    public boolean urlContainsComparison(String comparisonName) {
        String comparisonSlug = comparisonName.trim().toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-");
        return driver.getCurrentUrl().toLowerCase(Locale.ROOT).contains(comparisonSlug);
    }

    public boolean hasCollegeResults() {
        return isDisplayed(firstCollegeCard);
    }

    public void searchCollegeWithinRanking(String collegeName) {
        WebElement search = waits.untilVisible(rankingCollegeSearch);
        search.clear();
        search.sendKeys(collegeName);
        search.sendKeys(Keys.ENTER);
    }

    public boolean hasCollegeNamedInRanking(String collegeName) {
        String normalizedName = collegeName.trim().toLowerCase(Locale.ROOT);
        By matchingCollege = By.xpath("//main//a[contains(@href, '/college/') "
                + "and contains(translate(normalize-space(.),"
                + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), "
                + xpathLiteral(normalizedName) + ")]");
        try {
            return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                    .until(currentDriver -> currentDriver.findElements(matchingCollege).stream()
                            .anyMatch(WebElement::isDisplayed));
        } catch (TimeoutException exception) {
            return false;
        }
    }

    public boolean hasHeadingContaining(String expectedText) {
        String normalizedText = expectedText.toLowerCase(Locale.ROOT);
        String xpath = "//main//*[self::h1 or self::h2][contains(translate(normalize-space(.),"
                + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), " + xpathLiteral(normalizedText) + ")]";
        return isPresent(By.xpath(xpath));
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "',\"'\",'") + "')";
    }
}