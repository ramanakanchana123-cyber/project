package com.pages;

import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.parameters.ConfigReader;

public class QuestionPage extends BasePage {
    @FindBy(css = "iframe[src*='shikshaGPTBox']")
    private WebElement chatbotFrame;

    @FindBy(id = "chatBox")
    private WebElement chatbotInput;

    @FindBy(css = ".send-button")
    private WebElement chatbotSendButton;

    @FindBy(css = ".botui-message")
    private List<WebElement> chatbotMessages;

    @FindBy(id = "askTxtBx")
    private WebElement collegeQuestionTrigger;

    @FindBy(xpath = "//input[@placeholder='Write your question here']")
    private WebElement collegeQuestionModalInput;

    @FindBy(css = "a[href*='type=unanswered']")
    private WebElement unansweredQuestionsTab;

    @FindBy(xpath = "//*[self::h1 or self::h2 or self::h3 or self::h4]"
            + "[contains(translate(normalize-space(.),"
            + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'cutoff')"
            + " or contains(translate(normalize-space(.),"
            + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'cut-off')]")
    private List<WebElement> collegeCutoffHeadings;

    @FindBy(xpath = "//*[self::h1 or self::h2 or self::h3 or self::h4]"
            + "[contains(translate(normalize-space(.),"
            + " 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'ranking highlights')]")
    private List<WebElement> collegeRankingHeadings;
    private static final Pattern RANK_VALUE = Pattern.compile(
            "(?i)(?:rank(?:ed)?\\s*(?:no\\.?\\s*)?#?\\s*|#\\s*)(\\d{1,4})"
                    + "(?:\\s*[-–]\\s*(\\d{1,4}))?");
    @FindBy(xpath = "//div[contains(concat(' ', normalize-space(@class), ' '), ' question-actions ')]"
            + "/button[normalize-space()='Answer']")
    private List<WebElement> questionAnswerButtons;

    @FindBy(id = "shiksha-editor--ana-posting_ifr")
    private List<WebElement> answerEditorFrames;

    @FindBy(id = "tinymce")
    private WebElement answerEditorBody;

    @FindBy(xpath = "//*[normalize-space()='OK']")
    private List<WebElement> cookieOkButtons;

    @FindBy(xpath = "//*[normalize-space()='Required']")
    private List<WebElement> requiredQuestionMessages;

    @FindBy(xpath = "//button[starts-with(normalize-space(.),'Next')]")
    private List<WebElement> nextButtons;

    @FindBy(xpath = "//button[normalize-space()='Post']")
    private List<WebElement> postButtons;

    @FindBy(css = "input[placeholder='Mobile number'], input[placeholder='Email address']")
    private List<WebElement> loginPromptInputs;

    @FindBy(xpath = "//*[normalize-space()='No, Thanks' or normalize-space()='No Thanks']"
            + "/ancestor-or-self::*[self::button or self::a or @role='button'][1]")
    private List<WebElement> noThanksButtons;

    @FindBy(xpath = "//*[self::button or self::a][normalize-space()='OK']")
    private List<WebElement> cookieDismissButtons;

    @FindBy(tagName = "body")
    private WebElement pageBody;

    @FindBy(css = "select[name*='course'], [role='combobox'][aria-label*='Course']")
    private WebElement courseSelector;

    @FindBy(css = "textarea[name*='question'], textarea[placeholder*='question'], "
            + "input[name*='question'], input[placeholder='Write your question here']")
    private List<WebElement> questionInputs;

    @FindBy(css = "textarea[name*='description'], textarea[placeholder*='description']")
    private WebElement descriptionInput;

    public QuestionPage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public void openAskQuestionForm() {
        dismissQuestionPageOverlays();
        WebElement questionTrigger = waits.untilVisible(collegeQuestionTrigger);
        javascript.execute(
                "arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();",
                questionTrigger);
        waits.untilVisible(collegeQuestionModalInput);
    }

    public void openFirstUnansweredAnswerForm() {
        WebElement unansweredTab = waits.untilVisible(unansweredQuestionsTab);
        scrollTo(unansweredTab);
        click(unansweredTab);
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(ExpectedConditions.urlContains("type=unanswered"));
        waits.untilPageLoaded();
        dismissQuestionPageOverlays();

        WebElement firstAnswerButton = firstVisibleElement(questionAnswerButtons);
        scrollTo(firstAnswerButton);
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(ExpectedConditions.elementToBeClickable(firstAnswerButton));
        Set<String> originalWindows = driver.getWindowHandles();
        String unansweredPageUrl = driver.getCurrentUrl();
        click(firstAnswerButton);
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> currentDriver.getWindowHandles().size() > originalWindows.size()
                        || !currentDriver.getCurrentUrl().equals(unansweredPageUrl)
                        || !answerEditorFrames.isEmpty());
        if (driver.getWindowHandles().size() > originalWindows.size()) {
            for (String windowHandle : driver.getWindowHandles()) {
                if (!originalWindows.contains(windowHandle)) {
                    driver.switchTo().window(windowHandle);
                    break;
                }
            }
        }

        if (answerEditorFrames.isEmpty()) {
            WebElement questionAnswerButton = firstVisibleElement(questionAnswerButtons);
            scrollTo(questionAnswerButton);
            click(questionAnswerButton);
        }
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(answerEditorFrames.get(0)));
        try {
            waits.untilVisible(answerEditorBody);
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void openCollegeSection(String sectionName) {
        if (!"Cut-Offs".equals(sectionName) && !"Rankings".equals(sectionName)) {
            throw new IllegalArgumentException("Unsupported college section: " + sectionName);
        }
        By sectionLink = By.xpath("(//a|//button)[normalize-space()="
                + xpathLiteral(sectionName) + "]");
        WebElement link = firstVisibleElement(sectionLink);
        scrollTo(link);
        click(link);
        List<WebElement> headings = "Rankings".equals(sectionName)
                ? collegeRankingHeadings
                : collegeCutoffHeadings;
        scrollTo(firstVisibleElement(headings));
    }

    public boolean isCollegeCutoffDisplayed() {
        return collegeCutoffHeadings.stream()
                .anyMatch(WebElement::isDisplayed);
    }

    public boolean hasCollegeRankAbove(int threshold) {
        WebElement rankingHeading = firstVisibleElement(collegeRankingHeadings);
        scrollTo(rankingHeading);
        String text = pageBody.getText();
        Matcher matcher = RANK_VALUE.matcher(text);
        while (matcher.find()) {
            int rank = Integer.parseInt(matcher.group(1));
            if (rank > threshold) {
                return true;
            }
            if (matcher.group(2) != null
                    && Integer.parseInt(matcher.group(2)) > threshold) {
                return true;
            }
        }
        return false;
    }

    public void enterAnswer(String answer) {
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> !answerEditorFrames.isEmpty());
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(answerEditorFrames.get(0)));
        try {
            WebElement editor = waits.untilVisible(answerEditorBody);
            editor.sendKeys(answer);
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void openAskQuestionSubmissionForm() {
        dismissAdmissionAlertsIfPresent();
        firstVisibleElement(questionInputs);
    }

    public void chooseCourse(String course) {
        WebElement selector = waits.untilVisible(courseSelector);
        if ("select".equalsIgnoreCase(selector.getTagName())) {
            new Select(selector).selectByVisibleText(course);
        } else {
            click(selector);
            driver.findElement(By.xpath("//*[normalize-space()=" + xpathLiteral(course) + "]")).click();
        }
    }

    public void enterQuestion(String question) {
        WebElement input = firstVisibleElement(questionInputs);
        scrollTo(input);
        click(input);
        input.clear();
        input.sendKeys(question);
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> question.equals(input.getAttribute("value")));
    }

    public void submitQuestionWithoutCourse(String question) {
        enterQuestion(question);
        continueQuestionSubmission();
    }

    public void enterDescription(String description) {
        if (description != null && !description.isBlank()) {
            type(descriptionInput, description);
        }
    }

    public void continueQuestionSubmission() {
        click(firstVisibleElement(nextButtons));
    }

    public boolean postPageIsDisplayed() {
        return isVisible(postButtons);
    }

    public void postQuestion() {
        click(firstVisibleElement(postButtons));
    }

    public void postAnswer() {
        click(firstVisibleElement(postButtons));
    }

    public boolean isLoginPromptDisplayed() {
        return isVisible(loginPromptInputs)
                || driver.getCurrentUrl().toLowerCase().contains("login");
    }

    public boolean isQuestionRequiredMessageDisplayed() {
        return isVisible(requiredQuestionMessages);
    }

    public void submitChatbotQuestion(String question) {
        switchToChatbotFrame();
        try {
            type(waits.untilVisible(chatbotInput), question);
            click(waits.untilClickable(chatbotSendButton));
            new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                    .until(currentDriver -> chatbotMessages.size() >= 3);
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    private void dismissAdmissionAlertsIfPresent() {
        clickFirstDisplayed(noThanksButtons);
        clickFirstDisplayed(cookieDismissButtons);
    }

    private void clickFirstDisplayed(List<WebElement> candidates) {
        for (WebElement candidate : candidates) {
            if (candidate.isDisplayed()) {
                clickWithJavaScript(candidate);
                break;
            }
        }
    }

    private void dismissQuestionPageOverlays() {
        dismissAdmissionAlertsIfPresent();
        for (WebElement button : cookieOkButtons) {
            if (button.isDisplayed()) {
                clickWithJavaScript(button);
                break;
            }
        }
    }

    public boolean hasChatbotResponse() {
        switchToChatbotFrame();
        try {
            return chatbotMessages.size() >= 3
                    && !chatbotMessages.get(chatbotMessages.size() - 1).getText().isBlank();
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    private void switchToChatbotFrame() {
        new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(chatbotFrame));
    }

    private WebElement firstVisibleElement(List<WebElement> candidates) {
        return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> candidates.stream()
                        .filter(WebElement::isDisplayed)
                        .filter(WebElement::isEnabled)
                        .findFirst()
                        .orElse(null));
    }

    private WebElement firstVisibleElement(By locator) {
        return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                .until(currentDriver -> currentDriver.findElements(locator).stream()
                        .filter(WebElement::isDisplayed)
                        .filter(WebElement::isEnabled)
                        .findFirst()
                        .orElse(null));
    }

    private boolean isVisible(List<WebElement> candidates) {
        try {
            return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                    .until(currentDriver -> candidates.stream().anyMatch(WebElement::isDisplayed));
        } catch (TimeoutException exception) {
            return false;
        }
    }

    private boolean isVisible(By locator) {
        try {
            return new WebDriverWait(driver, config.getDuration("explicitWaitTimeout"))
                    .until(currentDriver -> currentDriver.findElements(locator).stream()
                            .anyMatch(WebElement::isDisplayed));
        } catch (TimeoutException exception) {
            return false;
        }
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "',\"'\",'") + "')";
    }
}
