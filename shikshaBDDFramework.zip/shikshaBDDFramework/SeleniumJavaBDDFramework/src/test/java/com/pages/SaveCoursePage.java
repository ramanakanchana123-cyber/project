package com.pages;

import com.parameters.ConfigReader;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SaveCoursePage extends BasePage {
    @FindBy(css = "main [data-testid='college-card'], main article, main [class*='college-card']")
    private WebElement firstCollegeCard;

    @FindBy(xpath = "(//main//*[self::button or self::a][contains(translate(normalize-space(.),"
            + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'shortlist') "
            + "or contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'save')])[1]")
    private WebElement firstShortlistAction;

    @FindBy(xpath = "//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),"
            + "'shortlisted') or contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'saved')]")
    private WebElement savedConfirmation;

    @FindBy(xpath = "(//main//*[self::button or self::a][contains(translate(normalize-space(.),"
            + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'shortlisted')])[1]")
    private List<WebElement> shortlistedActions;

    public SaveCoursePage(WebDriver driver, ConfigReader config) {
        super(driver, config);
    }

    public void shortlistFirstCollege() {
        if (!isDisplayed(firstCollegeCard)) {
            throw new IllegalStateException("No college result is available to shortlist");
        }
        click(firstShortlistAction);
    }

    public boolean isCollegeShortlisted() {
        return isDisplayed(savedConfirmation)
                || !shortlistedActions.isEmpty();
    }
}