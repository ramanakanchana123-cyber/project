package com.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;
import org.testng.ITestContext;

@CucumberOptions(
        features = "src/test/resources/Features",
        glue = {"com.stepDefinition", "com.setup"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "com.reporting.StepAutoLogger"
        },
        monochrome = true)
public class TestRunner extends AbstractTestNGCucumberTests {
    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios(ITestContext context) {
        return super.scenarios(context);
    }
}