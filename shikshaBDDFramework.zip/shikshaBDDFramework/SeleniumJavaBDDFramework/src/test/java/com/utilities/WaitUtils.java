package com.utilities;

import java.time.Duration;
import java.util.Objects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public final class WaitUtils {
    private final WebDriverWait wait;

    public WaitUtils(WebDriver driver, Duration timeout) {
        this.wait = new WebDriverWait(Objects.requireNonNull(driver, "driver"), timeout);
    }

    public WebElement untilVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement untilClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement untilPresent(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    public WebElement untilSelected(By locator) {
        wait.until(ExpectedConditions.elementSelectionStateToBe(locator, true));
        return untilPresent(locator);
    }

    public boolean untilInvisible(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public boolean untilUrlContains(String value) {
        return wait.until(ExpectedConditions.urlContains(value));
    }

    public boolean untilPageLoaded() {
        return wait.until(driver -> "complete".equals(
                ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("return document.readyState")));
    }
}
