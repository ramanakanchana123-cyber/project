package com.utilities;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public final class ScreenshotUtils {
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS");

    private ScreenshotUtils() {
    }

    public static Path capture(WebDriver driver, Path directory, String scenarioName) throws IOException {
        Objects.requireNonNull(driver, "driver");
        Files.createDirectories(directory);
        String safeName = scenarioName.replaceAll("[^A-Za-z0-9._-]", "_");
        Path target = directory.resolve(safeName + "-" + LocalDateTime.now().format(FILE_TIME) + ".png");
        byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        return Files.write(target, screenshot);
    }
}
