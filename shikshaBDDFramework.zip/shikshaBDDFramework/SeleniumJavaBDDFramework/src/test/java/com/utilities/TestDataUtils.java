package com.utilities;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public final class TestDataUtils {
    private TestDataUtils() {
    }

    public static List<Map<String, String>> readSheet(Path workbookPath, String sheetName) throws IOException {
        try (InputStream input = Files.newInputStream(workbookPath);
             Workbook workbook = WorkbookFactory.create(input)) {
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Excel sheet not found: " + sheetName);
            }
            Row header = sheet.getRow(sheet.getFirstRowNum());
            if (header == null || header.getLastCellNum() < 1) {
                throw new IllegalArgumentException("Excel sheet has no header row: " + sheetName);
            }

            DataFormatter formatter = new DataFormatter();
            List<String> headers = new ArrayList<>();
            for (int column = 0; column < header.getLastCellNum(); column++) {
                String name = formatter.formatCellValue(header.getCell(column)).trim();
                if (name.isBlank()) {
                    throw new IllegalArgumentException("Excel header is blank at column " + column);
                }
                headers.add(name);
            }

            List<Map<String, String>> records = new ArrayList<>();
            for (int rowIndex = header.getRowNum() + 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) {
                    continue;
                }
                Map<String, String> record = new LinkedHashMap<>();
                for (int column = 0; column < headers.size(); column++) {
                    record.put(headers.get(column), formatter.formatCellValue(row.getCell(column)).trim());
                }
                records.add(Map.copyOf(record));
            }
            return List.copyOf(records);
        }
    }
}
