package com.utilities;

import java.util.Objects;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public final class ElementUtils {
    private final WaitUtils waits;

    public ElementUtils(WaitUtils waits) {
        this.waits = Objects.requireNonNull(waits, "waits");
    }

    public void click(WebElement element) {
        waits.untilClickable(element).click();
    }

    public void type(WebElement element, String value) {
        WebElement visibleElement = waits.untilVisible(element);
        visibleElement.clear();
        visibleElement.sendKeys(value);
    }

    public void typeAndSubmit(WebElement element, String value) {
        WebElement visibleElement = waits.untilVisible(element);
        visibleElement.clear();
        visibleElement.sendKeys(value, Keys.ENTER);
    }

    public String text(WebElement element) {
        return waits.untilVisible(element).getText().trim();
    }

    public boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException
                 | org.openqa.selenium.StaleElementReferenceException exception) {
            return false;
        }
    }
}
