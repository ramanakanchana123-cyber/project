package com.utilities;

import java.util.Objects;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public final class JavaScriptUtils {
    private final JavascriptExecutor executor;

    public JavaScriptUtils(WebDriver driver) {
        if (!(Objects.requireNonNull(driver, "driver") instanceof JavascriptExecutor javascriptExecutor)) {
            throw new IllegalArgumentException("The configured WebDriver does not support JavaScript execution");
        }
        this.executor = javascriptExecutor;
    }

    public void scrollIntoView(WebElement element) {
        executor.executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
    }

    public void click(WebElement element) {
        executor.executeScript("arguments[0].click();", element);
    }

    public Object execute(String script, Object... arguments) {
        return executor.executeScript(script, arguments);
    }
}
