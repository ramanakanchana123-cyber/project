@TC-001 @smoke @regression
Feature: Search for a ranked MBA college
  Background:
    Given the applicant is on the Shiksha home page

  Scenario: Search for a ranked MBA college from Excel test data
    When the applicant selects the MBA module
    And the applicant opens top ranked MBA colleges
    And the applicant searches for the college from Excel within the ranking
    Then the college from Excel should appear in the ranking results