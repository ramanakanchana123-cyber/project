@regression
Feature: Compare MBA programmes
  Background:
    Given the applicant is on the Shiksha home page

  @TC-008
  Scenario: Open a popular MBA comparison from Excel
    When the applicant selects the MBA module
    And the applicant opens the popular MBA comparison from Excel
    Then the comparison URL should contain the comparison from Excel