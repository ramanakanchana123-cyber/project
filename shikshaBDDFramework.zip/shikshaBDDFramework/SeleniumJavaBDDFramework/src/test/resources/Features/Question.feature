@regression
Feature: Ask questions about MBA programmes
  Background:
    Given the applicant is on the Shiksha home page

  @TC-018 @qa-submission @tc018-submit
  Scenario Outline: Submit an MBA admission question from the MBA resources page
    When the applicant opens Ask a Question from MBA resources
    And the applicant enters the question "<question>"
    And the applicant continues to the next question step
    Then the next question step should show the Post action
    When the applicant clicks Post
    Then a sign-in prompt should be displayed to post the question

    Examples:
      | question                                      |
      | What is the CAT cutoff for IIM Ahmedabad?     |

  @TC-018 @qa-submission @tc018-whitespace
  Scenario: Prevent a whitespace-only MBA admission question from reaching the Post step
    When the applicant opens Ask a Question from MBA resources
    And the applicant enters the question "                    "
    And the applicant continues to the next question step
    Then the applicant should remain on the question form

  @TC-018 @qa-submission @tc018-college-data
  Scenario: View cutoffs and rankings for an MBA college
    When the applicant opens the MBA student questions page
    Then the college sections should match these checks:
      | section  | check           | threshold |
      | Cut-Offs | details-visible |           |
      | Rankings | rank-above      | 70        |

 
