@regression @TC-017
Feature: Access MBA exam preparation material
  Background:
    Given the applicant is on the Shiksha home page

  Scenario: Open an exam syllabus PDF
    When the applicant opens an exam syllabus PDF from MBA exams:
      | exam |
      | CAT  |
    Then the exam PDF should open successfully
