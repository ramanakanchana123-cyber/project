@regression
Feature: Filter MBA college listings
  Background:
    Given the applicant is on the Shiksha home page

  Scenario Outline: Find ranked colleges by location
    When the applicant selects the MBA module
    And the applicant opens top ranked MBA colleges
    And the applicant filters colleges by location "<location>"
    Then the location filter "<location>" should be selected

    Examples:
      | location  |
      | Hyderabad |
      | Bangalore |