# Skill: Selenium Code Generation

## Skill
Selenium Code Generation

## Used by which agent
Automation Agent; Selenium Validator Agent

## Include
- Generate clean and maintainable Selenium automation code.
- Use explicit waits and avoid unnecessary hard waits.
- Use locator priority: id → name → css → xpath.
- Keep test data externalized and avoid hardcoded values.
- Add meaningful assertions and validations.
- Include exception handling, logging, and screenshots where applicable.

## Output 
- Selenium test classes.
- Step definition implementations.
- Page Object method usage.
- Assertions and validations.
- Wait handling and synchronization logic.
- Test data integration (Excel/CSV/JSON) when applicable.
- Logging and screenshot capture code where required.

