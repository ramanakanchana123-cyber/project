# Skill: Page Object Generation

## Skill
Page Object Generation

## Used by which agent
- Automation Agent,
- Selenium Validator Agent

## Responsibilities
- Use private locators and variables.
- Generate reusable business methods instead of exposing locators.
- Use @FindBy annotations where applicable.
- Follow locator priority: id → name → css → xpath.
- Avoid duplicate and unstable locators.
- Add getter/setter methods only when required.
- Reuse common actions and utilities.
- Constructor with WebDriver initialization

## Output 
- Page/component classes
- Locator strategy notes 
- Page Object Class
- WebElements with locators
- Action methods
- Validation methods
- Reusable page components

