# Skill: Step Definition Generation

## Skill
Step Definition Generation

## Used by which agent
Automation Agent; Master QA Agent
## include
- Generate step definitions from feature files.
- Map Gherkin steps to Page Object methods.
- Reuse existing steps when possible.
- Avoid hardcoded data.
- Reusable implementation
- Assertions included
- Exception handling

## Output
- Step definition classes.
- Gherkin step mappings.
