# Skill: DataProvider Generation

## Skill
DataProvider Generation

## Used by which agent
- BDD Agent
- Automation Framework Agent
- Master QA Agent

## Include
- Create reusable test data providers for automated tests.
- Separate test data from automation scripts.
- Support data-driven test execution.
- Read test data from Excel, CSV, JSON, or external sources.
- Avoid hardcoded test data in test scripts.
- Support positive, negative, and boundary test data.
## Output
- DataProvider class or method.
- External test data references (Excel/CSV/JSON).
- Reusable test data structure.
- Parameterized test execution support.
