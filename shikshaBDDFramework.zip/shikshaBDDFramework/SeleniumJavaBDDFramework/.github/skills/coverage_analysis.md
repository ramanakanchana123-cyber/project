# Skill: Coverage Analysis

## Skill
Coverage Analysis

## Used by which agent
-Master QA Agent
-BDD Agent
-Review Agent
- Defect Agent

## Include
Requirement Coverage
Scenario Coverage
Test Coverage
Positive & Negative Coverage
Boundary Coverage


## Output 
Coverage %
Gap Analysis
Missing Scenarios
Recommendations
