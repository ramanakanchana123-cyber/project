# Skill: Hook Generation

## Skill
Hook Generation

## Used by which agent
- BDD Agent
- Automation Framework Agent
- Master QA Agent


## Include
- Execute common setup activities before scenarios.
- Perform cleanup activities after execution.
- Capture execution details after each step.
- Take screenshots automatically for failed scenarios.
- Maintain reusable and framework-independent hooks.
- Control hook execution using tags.
## Output
- Hook class with Before, After, BeforeStep, and AfterStep methods.
- Screenshot capture logic for failures.
- Driver setup and teardown implementation.
- Reporting and logging integration.
- External configuration references (Properties/JSON/YAML).

