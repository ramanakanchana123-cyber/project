# Skill: Code Validation

## Skill
Code Validation
## Used by which agent
Selenium Validator Agent
Review Agent
 Master QA Agent

## Include
- Static inspection of syntax, imports,  selectors, waits, exceptions, and resource cleanup
- Check dependency versions and config property names
-Confirm generated output is under target/Reports
## Output 
- Validation report with severity and evidence
- Build/test command output summary when executed
- Fix recommendations and unresolved checks

