# Skill: Feature Generation

## Skill
Feature Generation


## Used by which agent
-BDD Agent
- Master QA Agent

## Include
- Use Background for common preconditions.
- Use Scenario Outline and Examples for data-driven scenarios.
- Use Data Tables when multiple input values are needed.
- Avoid hardcoded test data.
- Use external test data sources such as Excel, CSV.
-Write concise business-language Given/When/Then steps
## Output
- Feature file with Feature, Background, Scenario, or Scenario Outline.
- Data Tables.
- Reusable test data references (Excel/CSV/JSON) when needed.
