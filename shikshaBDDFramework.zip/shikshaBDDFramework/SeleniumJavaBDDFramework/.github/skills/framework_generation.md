# Skill: Framework Generation

## Skill
Framework Generation

## Used by which agent
- Automation Agent
- Master QA Agent
- Review Agent

## Include
- Follow existing project structure and standards.
- Create reusable framework components.
- Support environment-based configuration.
- Include logging and reporting.
- Consider parallel execution where applicable.

## Output
- Framework files.
- Folder structure.
- Run commands.
- Notes and limitations.
