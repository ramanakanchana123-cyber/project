# Skill: Defect Analysis

## Skill
Defect Analysis

## Objective
Classify test failures, investigate likely causes, and produce reproducible defect reports grounded in evidence.

## Used by which agent
-Defect Agent
- Master QA Agent
- Selenium Validator Agent

## Include
- Gather reproduction steps, expected/actual result, logs, screenshots, environment, browser, and build details


## Output
- Failure classification, severity, confidence, and evidence
- Root Cause
- Fix Recommendation
- Prevention Actions
